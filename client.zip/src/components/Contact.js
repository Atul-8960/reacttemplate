import React from 'react'

export const Contact = () => {
    return (
        <div>
        <h1>we are in contact page</h1>

            
        </div>
    )
}

export default Contact;
