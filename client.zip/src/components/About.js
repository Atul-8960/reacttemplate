import React from 'react'

export const About = () => {
    return (
        <div>
            <h1>we are in about page</h1>
            
        </div>
    )
}

export default About;
