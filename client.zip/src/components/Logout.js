import React from 'react'

export const Logout = () => {
    return (
        <div>
        <h1>we are in logout page</h1>
            
        </div>
    )
}

export default Logout;
