import React from 'react'

export const Home = () => {
    return (
        <div>
         <h1>we are in home page</h1>

            
        </div>
    )
}

export default Home;
