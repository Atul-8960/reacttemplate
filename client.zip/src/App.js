import logo from './logo.svg';
import './App.css';
import {Route} from "react-router-dom";
import Navbar from './components/Navbar';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/Contact';
import Register from './components/Register';
import Login from './components/Login';






function App() {
  return (
    <>
    <Navbar />

    <Route exact path ="/">
    <Home />
    </Route>

    <Route path ="/about">
    <About />
    </Route>

    <Route path ="/login">
    <Login />
    </Route>

    <Route path ="/contact">
    <Contact />
    </Route>

    
    <Route path ="/register">
    <Register />
    </Route>

    </>
  );
}

export default App;
